<h1 align="center"> MARIO GAME HTML 5</h1>

<a href="https://dinhphuc.github.io/Mario/" align="center" title="Click to play"  target="_blank">
  <img src="https://i.imgur.com/K6Gnw6q.png">
</a>
